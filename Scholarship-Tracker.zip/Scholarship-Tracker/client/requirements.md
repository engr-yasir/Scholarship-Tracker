## Packages
recharts | For analytics dashboard charts (pie, bar)
date-fns | For date formatting and deadline calculations
framer-motion | For page transitions and smooth UI interactions
react-day-picker | For deadline date selection

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
